package redis

import "github.com/go-redis/redis/v8"

// CreateRedis redis 连接握手
func CreateRedis(lists int) *redis.Client {
	rdb := redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "",    // no password set
		DB:       lists, // use default DB
	})

	return rdb
}
